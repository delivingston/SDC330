
/*
 * Name: Dale Livingston II
 * Date: October 24, 2026
 * Assignment: SDC330 Course Project - Phase 1
 * Description: Stores customer information and allows financial details to be updated.
 */

public class Customer {
    private final int customerID;
    private final String name;
    private double annualIncome;
    private int creditScore;

    public Customer(int customerID, String name, double annualIncome, int creditScore) {
        this.customerID = customerID;
        this.name = name;
        this.annualIncome = annualIncome;
        this.creditScore = creditScore;
    }

    public int getCustomerID() { return customerID; }
    public String getName() { return name; }
    public double getAnnualIncome() { return annualIncome; }
    public int getCreditScore() { return creditScore; }

    public void setAnnualIncome(double annualIncome) {
        this.annualIncome = annualIncome;
    }

    public void setCreditScore(int creditScore) {
        this.creditScore = creditScore;
    }
}
