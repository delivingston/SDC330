
/*
 * Name: Dale Livingston II
 * Date: October 24, 2026
 * Assignment: SDC330 Course Project - Phase 1
 * Description: Runs the command-line loan application menu.
 */

import java.util.ArrayList;
import java.util.Scanner;

public class App {
    private static Scanner scanner = new Scanner(System.in);
    private static ArrayList<LoanApplication> applications = new ArrayList<>();
    private static int nextId = 1;

    public static void main(String[] args) {
        System.out.println("Dale Livingston II - Loan Application Management System (Phase 1)");

        int choice;

        do {
            displayMenu();
            choice = readInt("Enter your choice: ");

            switch (choice) {
                case 1 -> createApplication();
                case 2 -> viewApplications();
                case 3 -> updateApplication();
                case 4 -> deleteApplication();
                case 5 -> System.out.println("Goodbye!");
                default -> System.out.println("Please choose 1 through 5.");
            }
        } while (choice != 5);

        scanner.close();
    }

    public static void displayMenu() {
        System.out.println("\n1. Create loan application");
        System.out.println("2. View applications");
        System.out.println("3. Update customer information");
        System.out.println("4. Delete application");
        System.out.println("5. Exit");
    }

    private static int readInt(String prompt) {
        while (true) {
            System.out.print(prompt);
            try {
                return Integer.parseInt(scanner.nextLine().trim());
            } catch (NumberFormatException e) {
                System.out.println("Enter a whole number.");
            }
        }
    }

    private static double readDouble(String prompt) {
        while (true) {
            System.out.print(prompt);
            try {
                return Double.parseDouble(scanner.nextLine().trim());
            } catch (NumberFormatException e) {
                System.out.println("Enter a valid number.");
            }
        }
    }

    private static int readRange(String prompt, int min, int max) {
        while (true) {
            int value = readInt(prompt);
            if (value >= min && value <= max) {
                return value;
            }
            System.out.println("Enter a number between " + min + " and " + max + ".");
        }
    }

    private static double readPositive(String prompt) {
        while (true) {
            double value = readDouble(prompt);
            if (Double.isFinite(value) && value > 0) {
                return value;
            }
            System.out.println("Enter a positive number.");
        }
    }

    private static void createApplication() {
        System.out.print("Customer name: ");
        String name = scanner.nextLine().trim();

        while (name.isEmpty()) {
            System.out.print("Name cannot be empty. Customer name: ");
            name = scanner.nextLine().trim();
        }

        double income = readPositive("Annual income: ");
        int score = readRange("Credit score (300-850): ", 300, 850);
        double amount = readPositive("Loan amount: ");
        int months = readRange("Loan term in months (1-360): ", 1, 360);
        double rate = 8.0;

        Customer customer = new Customer(nextId, name, income, score);
        Loan loan = new PersonalLoan(amount, months, rate);

        LoanApplication application = new LoanApplication(nextId, customer, loan);
        application.checkEligibility();
        applications.add(application);
        nextId++;

        System.out.println("\n" + application.getApplicationSummary());
    }

    private static void viewApplications() {
        if (applications.isEmpty()) {
            System.out.println("No applications found.");
            return;
        }

        for (LoanApplication application : applications) {
            System.out.println("\n" + application.getApplicationSummary());
        }
    }

    private static LoanApplication findApplication(int id) {
        for (LoanApplication application : applications) {
            if (application.getApplicationId() == id) {
                return application;
            }
        }
        return null;
    }

    private static void updateApplication() {
        int id = readInt("Application ID to update: ");
        LoanApplication application = findApplication(id);

        if (application == null) {
            System.out.println("Application not found.");
            return;
        }

        Customer customer = application.getCustomer();
        customer.setAnnualIncome(readPositive("New annual income: "));
        customer.setCreditScore(readRange("New credit score (300-850): ", 300, 850));

        application.checkEligibility();

        System.out.println("Updated application:\n" + application.getApplicationSummary());
    }

    private static void deleteApplication() {
        int id = readInt("Application ID to delete: ");
        LoanApplication application = findApplication(id);

        if (application == null) {
            System.out.println("Application not found.");
        } else {
            applications.remove(application);
            System.out.println("Application deleted.");
        }
    }
}
