
/*
 * Name: Dale Livingston II
 * Date: October 24, 2026
 * Assignment: SDC330 Course Project - Phase 1
 * Description: Connects a customer and loan and checks example eligibility rules.
 */

public class LoanApplication {
    private final int applicationId;
    private final Customer customer;
    private Loan loan;
    private String status;
    private String decisionReason;

    public LoanApplication(int applicationId, Customer customer, Loan loan) {
        this.applicationId = applicationId;
        this.customer = customer;
        this.loan = loan;
        this.status = "Pending";
        this.decisionReason = "Not reviewed";
    }

    public LoanApplication(int applicationId, Customer customer) {
        this.applicationId = applicationId;
        this.customer = customer;
    }

    public int getApplicationId() { return applicationId; }
    public Customer getCustomer() { return customer; }
    public Loan getLoan() { return loan; }
    public String getStatus() { return status; }
    public String getDecisionReason() { return decisionReason; }

    // Example classroom eligibility rules; not real lending criteria.
    public boolean checkEligibility() {
        if (customer.getCreditScore() < 600) {
            status = "Denied";
            decisionReason = "Credit score is below 600.";
        } else if (customer.getAnnualIncome() < 30000) {
            status = "Denied";
            decisionReason = "Annual income is below $30,000.";
        } else if (loan.getLoanAmount() <= 0 || loan.getLoanTerm() <= 0) {
            status = "Denied";
            decisionReason = "Loan amount and term must be positive.";
        } else {
            status = "Initially Eligible";
            decisionReason = "Meets the example income and credit requirements.";
        }

        return status.equals("Initially Eligible");
    }

    public String getApplicationSummary() {
        return String.format(
            "Application ID: %d%nCustomer: %s%nAnnual Income: $%,.2f%n" +
            "Credit Score: %d%nLoan Amount: $%,.2f%nLoan Term: %d months%n" +
            "Interest Rate: %.2f%%%nEstimated Monthly Payment: $%,.2f%n" +
            "Status: %s%nReason: %s",
            applicationId, customer.getName(), customer.getAnnualIncome(),
            customer.getCreditScore(), loan.getLoanAmount(), loan.getLoanTerm(),
            loan.getInterestRate(), loan.calculateMonthlyPayment(), status, decisionReason);
    }
}
