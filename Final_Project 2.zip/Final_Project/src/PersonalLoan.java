/*
 * Name: Dale Livingston II
 * Date: October 24, 2026
 * Assignment: SDC330 Course Project - Phase 1
 * Description: Extends Loan and overrides its payment method.
 */

public class PersonalLoan extends Loan {

    public PersonalLoan(double loanAmount, int loanTerm, double interestRate) {
        super(loanAmount, loanTerm, interestRate);
    }

    @Override
    public double calculateMonthlyPayment() {
        return super.calculateMonthlyPayment();
    }
}