/*
 * Name: Dale Livingston II
 * Date: October 24, 2026
 * Assignment: SDC330 Course Project - Phase 1
 * Description: Stores loan information and calculates estimated monthly payments.
 */

public class Loan {
    private double loanAmount;
    private final int loanTerm;
    private double interestRate;

    public Loan(double loanAmount, int loanTerm, double interestRate) {
        this.loanAmount = loanAmount;
        this.loanTerm = loanTerm;
        this.interestRate = interestRate;
    }

    public Loan(int loanTerm) {
        this.loanTerm = loanTerm;
    }

    public double getLoanAmount() { return loanAmount; }
    public int getLoanTerm() { return loanTerm; }
    public double getInterestRate() { return interestRate; }

    public double calculateMonthlyPayment() {
        if (loanTerm <= 0 || loanAmount <= 0) {
            return 0;
        }

        double monthlyRate = interestRate / 100.0 / 12.0;

        if (monthlyRate == 0) {
            return loanAmount / loanTerm;
        }

        double factor = Math.pow(1 + monthlyRate, loanTerm);

        return loanAmount * monthlyRate * factor / (factor - 1);
    }
}