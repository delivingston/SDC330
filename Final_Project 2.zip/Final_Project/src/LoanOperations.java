/*
 * Name: Dale Livingston II
 * Date: October 28, 2026
 * Assignment: SDC330 Course Project
 * Description: Interface that defines the operations
 * required for a loan application.
 */

public interface LoanOperations {

    // Check if the customer meets loan requirements
    boolean checkEligibility();

    // Return the reason for the loan decision
    String getDecisionReason();

    // Return the current application status
    String getStatus();

    // Display the loan application information
    String getApplicationSummary();
}