/*
 * Name: Dale Livingston II
 * Date: October 29, 2026
 * Assignment: SDC330 Course Project - Phase 2
 * Description: Loan application menu with persistent SQLite CRUD operations.
 */

import java.sql.SQLException;
import java.util.Scanner;

public class App {

    private static final Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {

        System.out.println(
                "Dale Livingston II - Loan Application Management System (Phase 2)"
        );

        System.out.println(
                "Welcome! Create, view, update, or delete loan applications."
        );

        System.out.println(
                "Applications are saved in the SQLite database."
        );

        // Connect to SQLite database
        try (LoanDatabase database = new LoanDatabase()) {

            int choice;

            do {

                System.out.println("\n1. Create loan application");
                System.out.println("2. View applications");
                System.out.println("3. Update customer information");
                System.out.println("4. Delete application");
                System.out.println("5. Exit");

                choice = readInt("Enter your choice: ");

                try {

                    switch (choice) {

                        case 1 -> createApplication(database);

                        case 2 -> viewApplications(database);

                        case 3 -> updateApplication(database);

                        case 4 -> deleteApplication(database);

                        case 5 -> System.out.println("Goodbye!");

                        default -> System.out.println(
                                "Please choose 1 through 5."
                        );
                    }

                } catch (SQLException error) {

                    System.out.println(
                            "Database error: " + error.getMessage()
                    );
                }

            } while (choice != 5);

        } catch (SQLException error) {

            System.out.println(
                    "Could not open database: " + error.getMessage()
            );

        } finally {

            scanner.close();
        }
    }

    // Read integer input
    private static int readInt(String prompt) {

        while (true) {

            System.out.print(prompt);

            try {

                return Integer.parseInt(
                        scanner.nextLine().trim()
                );

            } catch (NumberFormatException error) {

                System.out.println("Enter a whole number.");
            }
        }
    }

    // Read decimal input
    private static double readDouble(String prompt) {

        while (true) {

            System.out.print(prompt);

            try {

                return Double.parseDouble(
                        scanner.nextLine().trim()
                );

            } catch (NumberFormatException error) {

                System.out.println("Enter a valid number.");
            }
        }
    }

    // Validate a number within a range
    private static int readRange(String prompt, int min, int max) {

        while (true) {

            int value = readInt(prompt);

            if (value >= min && value <= max) {
                return value;
            }

            System.out.println(
                    "Enter a number between " + min + " and " + max + "."
            );
        }
    }

    // Validate positive decimal input
    private static double readPositive(String prompt) {

        while (true) {

            double value = readDouble(prompt);

            if (Double.isFinite(value) && value > 0) {
                return value;
            }

            System.out.println("Enter a positive number.");
        }
    }

    // CREATE: Create and save a loan application
    private static void createApplication(LoanDatabase database)
            throws SQLException {

        System.out.print("Customer name: ");

        String name = scanner.nextLine().trim();

        while (name.isEmpty()) {

            System.out.print(
                    "Name cannot be empty. Customer name: "
            );

            name = scanner.nextLine().trim();
        }

        double income = readPositive("Annual income: ");

        int score = readRange(
                "Credit score (300-850): ", 300, 850
        );

        double amount = readPositive("Loan amount: ");

        int months = readRange(
                "Loan term in months (1-360): ", 1, 360
        );

        // Example interest rate
        double rate = 8.0;

        // Get next available application ID
        int id = database.getNextId();

        // Create customer object
        Customer customer = new Customer(
                id, name, income, score
        );

        // Inheritance: PersonalLoan extends Loan
        Loan loan = new PersonalLoan(
                amount, months, rate
        );

        // Create loan application
        LoanApplication application = new LoanApplication(
                id, customer, loan
        );

        // Abstraction: Use LoanOperations interface
        LoanOperations operations = application;

        // Check eligibility
        operations.checkEligibility();

        // Save application to SQLite
        database.saveApplication(application);

        System.out.println(
                "\nSaved to database:\n"
                + operations.getApplicationSummary()
        );
    }

    // READ: View all saved loan applications
    private static void viewApplications(LoanDatabase database)
            throws SQLException {

        var applications = database.getApplications();

        if (applications.isEmpty()) {

            System.out.println("No applications found.");
            return;
        }

        // Display all saved applications
        for (LoanApplication application : applications) {

            LoanOperations operations = application;

            System.out.println(
                    "\n" + operations.getApplicationSummary()
            );
        }
    }

    // UPDATE: Update customer financial information
    private static void updateApplication(LoanDatabase database)
            throws SQLException {

        int id = readInt("Application ID to update: ");

        // Retrieve existing application from SQLite
        LoanApplication application = database.getApplication(id);

        if (application == null) {

            System.out.println("Application not found.");
            return;
        }

        Customer customer = application.getCustomer();

        // Update customer income
        customer.setAnnualIncome(
                readPositive("New annual income: ")
        );

        // Update credit score
        customer.setCreditScore(
                readRange("New credit score (300-850): ", 300, 850)
        );

        // Recheck eligibility
        LoanOperations operations = application;

        operations.checkEligibility();

        // Save updated information
        database.updateApplication(application);

        System.out.println(
                "Updated and saved:\n"
                + operations.getApplicationSummary()
        );
    }

    // DELETE: Delete a loan application
    private static void deleteApplication(LoanDatabase database)
            throws SQLException {

        int id = readInt("Application ID to delete: ");

        // Check whether application exists
        if (database.getApplication(id) == null) {

            System.out.println("Application not found.");
            return;
        }

        // Delete application from SQLite
        database.deleteApplication(id);

        System.out.println(
                "Application deleted from database."
        );
    }
}