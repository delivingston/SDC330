/*
 * Name: Dale Livingston II
 * Date: October 28, 2026
 * Assignment: SDC330 Course Project
 * Description: Connects customer and loan information,
 * checks eligibility, and implements LoanOperations.
 */

// Implements the LoanOperations interface
public class LoanApplication implements LoanOperations {

    private final int applicationId;
    private final Customer customer;
    private Loan loan;
    private String status;
    private String decisionReason;

    // Constructor
    public LoanApplication(int applicationId, Customer customer, Loan loan) {

        this.applicationId = applicationId;
        this.customer = customer;
        this.loan = loan;
        this.status = "Pending";
        this.decisionReason = "Not reviewed";
    }

    // Overloaded constructor
    public LoanApplication(int applicationId, Customer customer) {

        this.applicationId = applicationId;
        this.customer = customer;
        this.loan = null;
        this.status = "Pending";
        this.decisionReason = "Not reviewed";
    }

    // Used when loading an existing decision from SQLite.
    public LoanApplication(int applicationId, Customer customer, Loan loan,
                           String status, String decisionReason) {
        this(applicationId, customer, loan);
        this.status = status;
        this.decisionReason = decisionReason;
    }

    public int getApplicationId() {
        return applicationId;
    }

    public Customer getCustomer() {
        return customer;
    }

    public Loan getLoan() {
        return loan;
    }

    // Method required by LoanOperations interface
    @Override
    public String getStatus() {
        return status;
    }

    // Method required by LoanOperations interface
    @Override
    public String getDecisionReason() {
        return decisionReason;
    }

    // Interface method that checks loan eligibility
    @Override
    public boolean checkEligibility() {

        // Check if a loan has been assigned
        if (loan == null) {
            status = "Denied";
            decisionReason = "No loan information provided.";
        }

        // Check credit score
        else if (customer.getCreditScore() < 600) {
            status = "Denied";
            decisionReason = "Credit score is below 600.";
        }

        // Check annual income
        else if (customer.getAnnualIncome() < 30000) {
            status = "Denied";
            decisionReason = "Annual income is below $30,000.";
        }

        // Check loan amount and term
        else if (loan.getLoanAmount() <= 0 || loan.getLoanTerm() <= 0) {
            status = "Denied";
            decisionReason = "Loan amount and term must be positive.";
        }

        // Customer meets the requirements
        else {
            status = "Initially Eligible";
            decisionReason = "Meets the example income and credit requirements.";
        }

        return status.equals("Initially Eligible");
    }

    // Interface method that displays application information
    @Override
    public String getApplicationSummary() {

        if (loan == null) {
            return "Application ID: " + applicationId
                    + "\nCustomer: " + customer.getName()
                    + "\nStatus: " + status
                    + "\nReason: " + decisionReason;
        }

        return String.format(
                "Application ID: %d%n"
                + "Customer: %s%n"
                + "Annual Income: $%,.2f%n"
                + "Credit Score: %d%n"
                + "Loan Amount: $%,.2f%n"
                + "Loan Term: %d months%n"
                + "Interest Rate: %.2f%%%n"
                + "Estimated Monthly Payment: $%,.2f%n"
                + "Status: %s%n"
                + "Reason: %s",

                applicationId,
                customer.getName(),
                customer.getAnnualIncome(),
                customer.getCreditScore(),
                loan.getLoanAmount(),
                loan.getLoanTerm(),
                loan.getInterestRate(),
                loan.calculateMonthlyPayment(),
                status,
                decisionReason
        );
    }
}