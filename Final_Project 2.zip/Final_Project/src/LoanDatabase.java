/*
 * Name: Dale Livingston II
 * Date: October 29, 2026
 * Assignment: SDC330 Course Project - Phase 2
 * Description: SQLite database access for customers, loans, and applications.
 */

import java.sql.*;
import java.util.ArrayList;

public class LoanDatabase implements AutoCloseable {

    private final Connection connection;

    // Connect to SQLite and create tables
    public LoanDatabase() throws SQLException {

        connection = DriverManager.getConnection(
                "jdbc:sqlite:LoanApplications.db"
        );

        try (Statement statement = connection.createStatement()) {
            statement.execute("PRAGMA foreign_keys = ON");
        }

        createTables();
    }

    // Create database tables if they do not exist
    private void createTables() throws SQLException {

        try (Statement statement = connection.createStatement()) {

            statement.executeUpdate(
                    "CREATE TABLE IF NOT EXISTS Customers ("
                    + "CustomerID INTEGER PRIMARY KEY, "
                    + "Name TEXT NOT NULL, "
                    + "AnnualIncome REAL NOT NULL, "
                    + "CreditScore INTEGER NOT NULL)"
            );

            statement.executeUpdate(
                    "CREATE TABLE IF NOT EXISTS Loans ("
                    + "LoanID INTEGER PRIMARY KEY, "
                    + "LoanAmount REAL NOT NULL, "
                    + "LoanTerm INTEGER NOT NULL, "
                    + "InterestRate REAL NOT NULL, "
                    + "LoanType TEXT NOT NULL)"
            );

            statement.executeUpdate(
                    "CREATE TABLE IF NOT EXISTS LoanApplications ("
                    + "ApplicationID INTEGER PRIMARY KEY, "
                    + "CustomerID INTEGER NOT NULL UNIQUE, "
                    + "LoanID INTEGER NOT NULL UNIQUE, "
                    + "Status TEXT NOT NULL, "
                    + "DecisionReason TEXT NOT NULL, "
                    + "FOREIGN KEY(CustomerID) REFERENCES Customers(CustomerID), "
                    + "FOREIGN KEY(LoanID) REFERENCES Loans(LoanID))"
            );
        }
    }

    // Find the next available application ID
    public int getNextId() throws SQLException {

        try (Statement statement = connection.createStatement();
             ResultSet result = statement.executeQuery(
                     "SELECT COALESCE(MAX(ApplicationID), 0) + 1 "
                     + "FROM LoanApplications")) {

            return result.getInt(1);
        }
    }

    // CREATE: Save a loan application
    public void saveApplication(LoanApplication application)
            throws SQLException {

        Customer customer = application.getCustomer();
        Loan loan = application.getLoan();

        int id = application.getApplicationId();

        connection.setAutoCommit(false);

        try {

            // Save customer information
            try (PreparedStatement statement =
                    connection.prepareStatement(
                            "INSERT INTO Customers VALUES (?, ?, ?, ?)")) {

                statement.setInt(1, id);
                statement.setString(2, customer.getName());
                statement.setDouble(3, customer.getAnnualIncome());
                statement.setInt(4, customer.getCreditScore());

                statement.executeUpdate();
            }

            // Save loan information
            try (PreparedStatement statement =
                    connection.prepareStatement(
                            "INSERT INTO Loans VALUES (?, ?, ?, ?, ?)")) {

                statement.setInt(1, id);
                statement.setDouble(2, loan.getLoanAmount());
                statement.setInt(3, loan.getLoanTerm());
                statement.setDouble(4, loan.getInterestRate());
                statement.setString(5, "PersonalLoan");

                statement.executeUpdate();
            }

            // Save application information
            try (PreparedStatement statement =
                    connection.prepareStatement(
                            "INSERT INTO LoanApplications "
                            + "VALUES (?, ?, ?, ?, ?)")) {

                statement.setInt(1, id);
                statement.setInt(2, id);
                statement.setInt(3, id);
                statement.setString(4, application.getStatus());
                statement.setString(5, application.getDecisionReason());

                statement.executeUpdate();
            }

            connection.commit();

        } catch (SQLException error) {

            connection.rollback();
            throw error;

        } finally {

            connection.setAutoCommit(true);
        }
    }

    // Convert a database record into a LoanApplication object
    private LoanApplication readApplication(ResultSet result)
            throws SQLException {

        Customer customer = new Customer(
                result.getInt("CustomerID"),
                result.getString("Name"),
                result.getDouble("AnnualIncome"),
                result.getInt("CreditScore")
        );

        Loan loan = new PersonalLoan(
                result.getDouble("LoanAmount"),
                result.getInt("LoanTerm"),
                result.getDouble("InterestRate")
        );

        return new LoanApplication(
                result.getInt("ApplicationID"),
                customer,
                loan,
                result.getString("Status"),
                result.getString("DecisionReason")
        );
    }

    // SQL query used to retrieve application information
    private String selectSql() {

        return "SELECT a.ApplicationID, "
                + "c.CustomerID, c.Name, c.AnnualIncome, "
                + "c.CreditScore, l.LoanAmount, "
                + "l.LoanTerm, l.InterestRate, "
                + "a.Status, a.DecisionReason "
                + "FROM LoanApplications a "
                + "JOIN Customers c ON a.CustomerID = c.CustomerID "
                + "JOIN Loans l ON a.LoanID = l.LoanID ";
    }

    // READ: Retrieve one application using its ID
    public LoanApplication getApplication(int id)
            throws SQLException {

        try (PreparedStatement statement =
                connection.prepareStatement(
                        selectSql() + "WHERE a.ApplicationID = ?")) {

            statement.setInt(1, id);

            try (ResultSet result = statement.executeQuery()) {

                if (result.next()) {
                    return readApplication(result);
                }

                return null;
            }
        }
    }

    // READ: Retrieve all applications
    public ArrayList<LoanApplication> getApplications()
            throws SQLException {

        ArrayList<LoanApplication> applications = new ArrayList<>();

        try (Statement statement = connection.createStatement();
             ResultSet result = statement.executeQuery(
                     selectSql() + "ORDER BY a.ApplicationID")) {

            while (result.next()) {

                applications.add(readApplication(result));
            }
        }

        return applications;
    }

    // UPDATE: Update customer information and loan decision
    public void updateApplication(LoanApplication application)
            throws SQLException {

        connection.setAutoCommit(false);

        try {

            // Update customer information
            try (PreparedStatement statement =
                    connection.prepareStatement(
                            "UPDATE Customers SET "
                            + "AnnualIncome = ?, CreditScore = ? "
                            + "WHERE CustomerID = ?")) {

                statement.setDouble(
                        1, application.getCustomer().getAnnualIncome()
                );

                statement.setInt(
                        2, application.getCustomer().getCreditScore()
                );

                statement.setInt(
                        3, application.getCustomer().getCustomerID()
                );

                statement.executeUpdate();
            }

            // Update loan application decision
            try (PreparedStatement statement =
                    connection.prepareStatement(
                            "UPDATE LoanApplications SET "
                            + "Status = ?, DecisionReason = ? "
                            + "WHERE ApplicationID = ?")) {

                statement.setString(1, application.getStatus());
                statement.setString(2, application.getDecisionReason());
                statement.setInt(3, application.getApplicationId());

                statement.executeUpdate();
            }

            connection.commit();

        } catch (SQLException error) {

            connection.rollback();
            throw error;

        } finally {

            connection.setAutoCommit(true);
        }
    }

    // DELETE: Remove application, loan, and customer records
    public void deleteApplication(int id) throws SQLException {

        connection.setAutoCommit(false);

        try {

            // Delete application first because of foreign keys
            try (PreparedStatement statement =
                    connection.prepareStatement(
                            "DELETE FROM LoanApplications "
                            + "WHERE ApplicationID = ?")) {

                statement.setInt(1, id);
                statement.executeUpdate();
            }

            // Delete loan
            try (PreparedStatement statement =
                    connection.prepareStatement(
                            "DELETE FROM Loans WHERE LoanID = ?")) {

                statement.setInt(1, id);
                statement.executeUpdate();
            }

            // Delete customer
            try (PreparedStatement statement =
                    connection.prepareStatement(
                            "DELETE FROM Customers WHERE CustomerID = ?")) {

                statement.setInt(1, id);
                statement.executeUpdate();
            }

            connection.commit();

        } catch (SQLException error) {

            connection.rollback();
            throw error;

        } finally {

            connection.setAutoCommit(true);
        }
    }

    // Close SQLite connection
    @Override
    public void close() throws SQLException {

        connection.close();
    }
}